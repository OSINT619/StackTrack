# StackTrack
A simple program catalog application for managing and searching through programs.
